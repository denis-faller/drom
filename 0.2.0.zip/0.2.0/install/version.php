<?
$arModuleVersion = array(
	"VERSION" => "0.2.0",
	"VERSION_DATE" => "2020-01-23 09:00:00"
);
?>